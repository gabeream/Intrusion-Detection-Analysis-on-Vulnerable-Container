This folder lacks a formal PowerPoint and pipeline templates for our ML jobs. We forgoed the PowerPoint to have more
time to focus on finishing our report. We don't have the pipeline templates since we were unable to complete any
ML jobs, even after our meeting post-presentation on December 1's IDS class. The details of the error and troubleshooting
are given in the document. 